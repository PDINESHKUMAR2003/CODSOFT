import java.util.*;
public class NumberGame{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        Random random=new Random();
        System.out.println("Welcome to the Number Guessing Game!");
        System.out.println("How many rounds would you like to play?");
        int rounds=sc.nextInt();
        System.out.println("How many attempts do you want per round?");
        int maxAttempts=sc.nextInt();
        int score=0;
       for (int round=1;round<=rounds;round++){
        System.out.println("\nRound "+round);
        int targetNumber=random.nextInt(100)+1;
        int attempts=0;
        boolean correctGuess=false;
        while (attempts<maxAttempts){
            System.out.println("Guess the number between 1 and 100: ");
            int guess=sc.nextInt();
            attempts++;
            if (guess<targetNumber){
                System.out.println("Too low!");

            }
            else if(guess>targetNumber){
                System.out.println("Too high!");
            }
            else{
                System.out.println("Correct! You have guesses the number perfectly.");
                score++;
                correctGuess=true;
                break;
            }
        }
        if (!correctGuess){
            System.out.println("Out of attempts! The correct number was "+targetNumber);
        }
       } 
       System.out.println("\nGame over! Your score: "+score+" out of "+rounds);

}
}